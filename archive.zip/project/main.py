print("helooooooo")
print("world")